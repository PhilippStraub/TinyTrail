#!/usr/bin/env python3
"""One-command replication of Table 3 and Figure 4.

  1. runs analysis/analyze_benchmark.py on results/  ->  output/
  2. checks Table 3 against reference/table3_paper.csv
  3. checks Figure 4 against reference/fig-rover-results.pdf

Usage (from this folder, with the packages from requirements.txt installed):
  python run_replication.py
"""
import os
import subprocess
import sys
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

HERE = Path(__file__).resolve().parent

# Fixes the PDF CreationDate to the original figure's (2026-11-08 17:38:41 UTC).
# It only affects that metadata field, not any computed value or plotted pixel.
SOURCE_DATE_EPOCH = "1794159521"

PINNED = {}
for line in (HERE / "requirements.txt").read_text(encoding="utf-8").splitlines():
    line = line.split("#")[0].strip()
    if "==" in line:
        name, ver = line.split("==", 1)
        PINNED[name.strip()] = ver.strip()


def check_environment() -> None:
    print(f"[env] Python {sys.version.split()[0]} (original analysis: 3.11.0)")
    for pkg in ("numpy", "pandas", "scipy", "matplotlib"):
        try:
            have = version(pkg)
        except PackageNotFoundError:
            sys.exit(f"[env] {pkg} is not installed - run: pip install -r requirements.txt")
        want = PINNED.get(pkg)
        flag = "" if have == want else f"   <-- WARNING: requirements.txt pins {want}"
        print(f"[env] {pkg} {have}{flag}")


def run(args) -> int:
    env = dict(os.environ, SOURCE_DATE_EPOCH=SOURCE_DATE_EPOCH)
    sys.stdout.flush()  # keep our own messages before the subprocess output
    return subprocess.call([sys.executable, *args], cwd=HERE, env=env)


def main() -> int:
    check_environment()
    out_dir = HERE / "output"

    print("\n[1/3] Running analysis (takes about 5 minutes) ...")
    rc = run(["analysis/analyze_benchmark.py",
              "--results-dir", str(HERE / "results"),
              "--out-dir", str(out_dir)])
    if rc != 0:
        print("[1/3] analysis failed")
        return rc

    print("\n[2/3] Verifying Table 3 ...")
    rc_table = run(["verification/verify_table3.py", str(out_dir)])

    print("\n[3/3] Verifying Figure 4 ...")
    rc_fig = run(["verification/verify_figure4.py", str(out_dir)])

    ok = rc_table == 0 and rc_fig == 0
    print("\n" + ("REPLICATION SUCCESSFUL: Table 3 and Figure 4 match the paper."
                  if ok else "REPLICATION FAILED: see mismatches above."))
    print(f"Table 3 (formatted): {out_dir}/<dataset>/suitability_table.csv")
    print(f"Figure 4           : {out_dir / 'rover-lab' / 'figures' / 'rover-lab_summary_grid.pdf'}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
