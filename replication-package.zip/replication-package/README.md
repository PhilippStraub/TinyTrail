# Replication Package — Table 3 and Figure 4

Replication package for the paper *"Twin-Ready On-Device Learning: Selecting ML Model
Configurations under Resource Constraints"* (TinyTrail). It regenerates, from the raw
on-device measurements and without any hardware:

| Paper artifact | LaTeX label | Regenerated file |
|---|---|---|
| **Table 3** — results of the evaluation process (RQ1 datasets + RQ2 rover), sorted by suitability | `tab:suitability` | `output/<dataset>/suitability_table.csv` (formatted), `output/<dataset>/suitability_by_config.csv` (unrounded) |
| **Figure 4** — rover use case: accuracy, net energy per inference, memory, total inference time vs. reference samples per class | `fig:rover-results` | `output/rover-lab/figures/rover-lab_summary_grid.pdf` |

and automatically checks both against the paper.

## Quick start

Requires Python 3.11 (verified with 3.11.0, Windows 11). About 400 MB free disk space
for the unpacked data and ~5 minutes runtime.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python run_replication.py
```

Expected end of the output:

```
[Table 3] 124 checks (24 rows x 5 columns + 4 rankings), 0 mismatch(es)
[Table 3] OK - every cell matches the paper exactly.
[Figure 4] OK - reproduced PDF is byte-identical to the paper's figure.
REPLICATION SUCCESSFUL: Table 3 and Figure 4 match the paper.
```

## Contents

```
replication-package/
├── run_replication.py          one-command run: analysis + both checks
├── requirements.txt            pinned package versions
├── analysis/
│   └── analyze_benchmark.py    the paper's analysis pipeline, unchanged copy of
│                               server/benchmark/analysis/analyze_benchmark.py
├── results/                    raw measurements (12 scenarios = 4 datasets x 3 algorithms)
│   └── scenario_<dataset>_<algorithm>/
│       ├── exp_NNN_<pca>_spc<S>_s<seed>/   one experiment (720 per dataset)
│       │     experiment_metadata.json      config, timestamps, power summary, clock offset
│       │     merged_analysis_*.csv         per-inference prediction, ground truth, latency,
│       │                                   resource samples (RSS, CPU)
│       │     resource_usage_*.csv          on-device resource log (5 Hz)
│       │     power_exp_*.csv               external power-supply trace (8 Hz)
│       └── baseline_NNN/                   idle baseline block (3 runs) bracketing each cell
│             baseline_summary.json         idle power of the block
│             baseline_NNN_runK/merged_analysis_*.csv   idle CPU/RAM of each run
├── reference/
│   ├── table3_paper.csv        Table 3 exactly as printed in the paper
│   └── fig-rover-results.pdf   Figure 4 as embedded in the paper
└── verification/
    ├── verify_table3.py        cell-by-cell comparison at the paper's printed precision
    └── verify_figure4.py       byte-level comparison of the figure PDF
```

Datasets: `cifar10`, `imagenette`, `mnist` (RQ1) and `rover-lab` (RQ2, "Rover" in the
paper). Algorithms: `knn` (k-NN, k=3), `kmeans` (K-Means, m=3), `nearest_centroid` (NC),
each with and without PCA (95 % explained variance) → 6 configurations per dataset,
12 sample sizes (2, 5, 10, 20, …, 100 reference samples per class), 10 seeds.

## How the paper values are derived

`analyze_benchmark.py` implements the five analysis steps of the paper
(Section "Data Analysis Procedures"):

1. **Data alignment and baseline subtraction** — energy is re-aligned by the measured
   PC↔Pi clock offset if it is ≥ 0.125 s (never the case in this data set); idle power,
   CPU and RAM of the two bracketing baseline blocks are averaged and subtracted.
2. **Energy and accuracy** — net energy per inference `E = P̄_net · T̄`; accuracy from the
   per-inference predictions (200 test images per experiment).
3. **Seed-level aggregation** — mean and sample standard deviation over the 10 seeds per
   sample size.
4. **Sample-size level** — `Acc̄_c`, `Ē_c` and `σ_E,c` across the 12 sample sizes; robust
   saturation point `s*_c` (first sample size reaching 95 % of the maximum accuracy with a
   margin larger than the seed-level SEM); peak memory as feasibility check (512 MB).
5. **Suitability** — `Suitability_c = Acc̄_c / (Ē_c + σ_E,c) · s_min / s*_c` with `s_min = 2`,
   reported relative to the best configuration of each dataset.

Column mapping between the paper's Table 3 and `suitability_by_config.csv`:

| Table 3 | CSV column | Note |
|---|---|---|
| Acc̄ (%) | `accuracy_bar` × 100 | |
| Ē (J) | `EDP_bar` | historical name: the `EDP` columns hold the net energy per inference E = P̄·T̄ (J), not the energy-delay product |
| σ_E | `sigma_EDP` | |
| s* | `s_star` | empty = no saturation reached (n/a) |
| Suit. (%) | `suitability` / max(`suitability`) × 100 | |

Figure 4 plots, per configuration and sample size, the seed mean ± one sample standard
deviation (band) of `accuracy`, `EDP` (net energy per inference), `net_memory_rss_mb_mean`
and `latency_sum_ms` (columns `<metric>_mean` / `<metric>_std` in
`output/rover-lab/aggregated_by_config.csv`).

## Verification

* **Table 3**: `verify_table3.py` compares all 120 cells plus the ranking of each of the
  four datasets. Each cell is formatted with exactly the precision printed in the paper
  (e.g. `0.0044` → 4 decimals, `3.63E-05` → 3 significant figures) and compared as text.
* **Figure 4**: `verify_figure4.py` compares the regenerated PDF byte by byte with the
  figure file used in the paper. Byte identity needs matplotlib 3.10.9 (pinned) and
  `SOURCE_DATE_EPOCH=1794159521`, which `run_replication.py` sets so that the PDF's
  `CreationDate` metadata equals the original one. With other matplotlib versions the
  plotted data are the same but the layout shifts by a few pixels.

## Notes on the data selection

* The package contains exactly the files the analysis reads (12,720 files). Files the
  analysis does not use — `drift_detection_*.log`, `performance_*.json`,
  `power_baseline_*.csv`, `resource_usage_*.csv` of baseline runs, `benchmark_summary.json`
  and `results/baseline_power.csv` — are omitted. The complete raw data set is available in
  the repository under `server/benchmark/results/`.
* `scenario_imagenette_kmeans/exp_001_pca95var_spc2_s42` originally holds leftover files of
  two aborted earlier deployments (two `merged_analysis_*.csv`, three `resource_usage_*.csv`).
  The analysis selects the newest `merged_analysis` file by modification time and the first
  `resource_usage` file in directory order; because ZIP archives do not preserve
  modification times reliably, only the two files the original analysis read are included
  (`merged_analysis_20260723_180820.csv`, `resource_usage_20260723_180320.csv`). Using the
  other `merged_analysis` file instead changes no value of Table 3 (identical to 10 decimals).
* `experiment_metadata.json` contains absolute paths of the original measurement machine
  (`config_source`, `python_example_dir`, `raw_data_dir`). They are not needed: the analysis
  falls back to the per-inference labels. They only feed auxiliary columns
  (`raw_feature_dim`, `support_set_kb`, `classifier_state_kb`) that are not part of Table 3
  or Figure 4.
* Besides Table 3 and Figure 4, the run also writes the other per-dataset figures
  (`*_summary_grid.pdf` for CIFAR-10, Imagenette, MNIST), aggregated tables and an
  `analysis_report.md` per dataset to `output/`.

## License

AGPL-3.0, see `LICENSE` (same as the TinyTrail repository).
