#!/usr/bin/env python3
"""Check the regenerated Figure 4 (fig:rover-results) against the paper's figure file.

Compares <output-dir>/rover-lab/figures/rover-lab_summary_grid.pdf byte-for-byte
with reference/fig-rover-results.pdf (the PDF embedded in the paper).

Byte identity requires the pinned matplotlib version (requirements.txt) and
SOURCE_DATE_EPOCH=1794159521, which run_replication.py sets so that the PDF's
CreationDate equals the original one (2026-11-08 17:38:41 UTC). If only the
CreationDate differs (e.g. when the analysis was run without
run_replication.py), the check reports that separately.

Usage: python verification/verify_figure4.py [output-dir]
Exit code 0 = identical, 1 = different.
"""
import hashlib
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REFERENCE = HERE.parent / "reference" / "fig-rover-results.pdf"
DATE_RE = re.compile(rb"/CreationDate \([^)]*\)")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "output"
    generated = out_dir / "rover-lab" / "figures" / "rover-lab_summary_grid.pdf"
    ref, gen = REFERENCE.read_bytes(), generated.read_bytes()

    print(f"[Figure 4] paper     : {REFERENCE.name}  sha256={sha256(ref)}")
    print(f"[Figure 4] reproduced: {generated.name}  sha256={sha256(gen)}")
    if ref == gen:
        print("[Figure 4] OK - reproduced PDF is byte-identical to the paper's figure.")
        return 0

    if DATE_RE.sub(b"", ref) == DATE_RE.sub(b"", gen):
        print("[Figure 4] MISMATCH only in the PDF CreationDate metadata; "
              "run via run_replication.py (sets SOURCE_DATE_EPOCH) for byte identity.")
    else:
        print("[Figure 4] MISMATCH - PDF content differs. Check that the pinned "
              "package versions from requirements.txt are installed "
              "(matplotlib version changes the layout).")
    return 1


if __name__ == "__main__":
    sys.exit(main())
