#!/usr/bin/env python3
"""Check the regenerated Table 3 (tab:suitability) against the paper.

Reads   <output-dir>/<dataset>/suitability_by_config.csv  (written by analyze_benchmark.py)
and     reference/table3_paper.csv                         (values as printed in the paper)

Every paper cell is compared at exactly the precision it is printed with,
e.g. "0.0044" -> 4 decimals, "3.63E-05" -> 3 significant figures, "96.3" -> 1 decimal.
The row order (ranking by suitability) is checked as well.

Usage: python verification/verify_table3.py [output-dir]
Exit code 0 = all cells match, 1 = at least one mismatch.
"""
import csv
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
REFERENCE = HERE.parent / "reference" / "table3_paper.csv"
DATASETS = ["cifar10", "imagenette", "mnist", "rover-lab"]


def fmt_like(value: float, paper: str) -> str:
    """Format `value` with the same precision/notation as the paper string."""
    if "E" in paper.upper():
        mantissa = paper.upper().split("E")[0]
        decimals = len(mantissa.split(".")[1]) if "." in mantissa else 0
        return f"{value:.{decimals}E}"
    decimals = len(paper.split(".")[1]) if "." in paper else 0
    return f"{value:.{decimals}f}"


def main() -> int:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "output"
    with open(REFERENCE, newline="", encoding="utf-8") as f:
        paper_rows = list(csv.DictReader(f))

    checks, mismatches = 0, []
    for dataset in DATASETS:
        rows = [r for r in paper_rows if r["dataset"] == dataset]
        raw = pd.read_csv(out_dir / dataset / "suitability_by_config.csv")
        best = raw["suitability"].max()

        reproduced_order = raw.sort_values("suitability", ascending=False,
                                           na_position="last")["config"].tolist()
        paper_order = [r["config"] for r in rows]
        checks += 1
        if reproduced_order != paper_order:
            mismatches.append((dataset, "row order", " | ".join(paper_order),
                               " | ".join(reproduced_order)))

        for p in rows:
            r = raw[raw["config"] == p["config"]].iloc[0]
            reproduced = {
                # identical rounding to analyze_benchmark.build_suitability_table()
                "acc_pct": f"{round(r['accuracy_bar'] * 100, 2):.2f}",
                "E_J": fmt_like(r["EDP_bar"], p["E_J"]),
                "sigma_E": fmt_like(r["sigma_EDP"], p["sigma_E"]),
                "s_star": "n/a" if pd.isna(r["s_star"]) else str(int(r["s_star"])),
                "suit_pct": "n/a" if pd.isna(r["suitability"])
                            else fmt_like(r["suitability"] / best * 100, p["suit_pct"]),
            }
            for col, rep in reproduced.items():
                checks += 1
                expected = p[col].upper() if col in ("E_J", "sigma_E") else p[col]
                if rep != expected:
                    mismatches.append((dataset, f"{p['config']} / {col}", expected, rep))

    print(f"[Table 3] {checks} checks (24 rows x 5 columns + 4 rankings), "
          f"{len(mismatches)} mismatch(es)")
    for ds, what, exp, rep in mismatches:
        print(f"  MISMATCH {ds:<10} {what:<26} paper={exp:<10} reproduced={rep}")
    if not mismatches:
        print("[Table 3] OK - every cell matches the paper exactly.")
    return 1 if mismatches else 0


if __name__ == "__main__":
    sys.exit(main())
